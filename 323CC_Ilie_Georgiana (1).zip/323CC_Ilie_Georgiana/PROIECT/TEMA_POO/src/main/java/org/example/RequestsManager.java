package org.example;

public interface RequestsManager {
    void create_request(Request request);
    void remove_request(Request request);
}
