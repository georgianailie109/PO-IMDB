### Informatii utilizare checker:

> Rezolvati tema (crearea claselor) in directorul "src/main/java/org.example"
din scheletul de checker pus la dispozitie.

> In schelet exista un config file - "test/resources/checker_config.json".
Inlocuiti exemplele cu numele complete ale claselor (create de voi) care
implementeaza pattern-urile.

> Pentru a obtine numele complet al unei clase, puteti folosi functia
<NUME_CLASA.class.getCanonicalName();>.

> Pentru rularea checker-ului se va folosi comanda <./gradlew test>.
Daca folositi IntelliJ, se poate rula direct prin click dreapta pe folderul
test si selectarea optiunii Run Tests in TemaPOO2023.
