package org.example;

public interface ExperienceStrategy {
    public int calculateExperience();
}
