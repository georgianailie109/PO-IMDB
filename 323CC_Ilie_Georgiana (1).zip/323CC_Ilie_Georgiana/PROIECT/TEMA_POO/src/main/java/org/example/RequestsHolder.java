package org.example;
import java.util.*;
public class RequestsHolder {
    private static List<Request> requests = new ArrayList<>();
    public static void add_request(Request request) {
        requests.add(request);
    }
    public static void remove_request(Request request) {
        requests.remove(request);
    }
    public static List<Request> get_requests() {
        return new ArrayList<>(requests);
    }

    public static void setRequests(List<Request> requests) {
        RequestsHolder.requests = requests;
    }
}
