Ilie Georgiana-Elena, 323CC

TEMA POO 2023

Timpul alocat rezolvarii: 7 zile

Am implementat in terminal aplicatia IMDB, unde utilizatorii pot interactiona
cu o baza de date de filme, seriale si actori. Functionalitatile includ
autentificare, gestionarea productiilor si actorilor, adaugarea si stergerea
de date si crearea si gestionarea cererilor. Utilizez biblioteca Jackson pentru
a citi date din fisierele JSON si pentru a popula baza de date. Utilizatorii
pot fi regular, contribuitori sau admini, in functie de tipul acestuia,
realizandu-se operatiile permise.
