package org.example;
import CLI.InformationIncompleteException;
import CLI.InvalidCommandException;
import CLI.RunCLI;

import java.util.ArrayList;
import java.util.List;

public class IMDB {
    private static IMDB imdb = null;
    private List<User> users = new ArrayList<>();
    private List<Actor> actors = new ArrayList<>();
    private List<Request> requests = new ArrayList<>();
    private List<Production> productions = new ArrayList<>();
    private User currentUser = null;
    private IMDB() {}
    private IMDB(List<User> users, List<Actor> actors, List<Request> requests, List<Production> productions) {
        this.users = users;
        this.actors = actors;
        this.requests = requests;
        this.productions = productions;
    }

    public static IMDB getImdb() {
        if (imdb == null) imdb = new IMDB();
        return imdb;
    }

    public void run() {
        JSONReader reader = new JSONReader();
        reader.read_accounts();
        reader.read_actors();
        reader.read_productions();
        reader.read_requests();
    }

    public static void main(String[] args) throws InformationIncompleteException, InvalidCommandException {
        imdb = getImdb();
        imdb.run();

        new RunCLI();
    }

    public List<Production> getProductions() {
        return productions;
    }

    public List<User> getUsers() {
        return users;
    }

    public List<Actor> getActors() {
        return actors;
    }

    public List<Request> getRequests() {
        return requests;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setActors(List<Actor> actors) {
        this.actors = actors;
    }

    public void setRequests(List<Request> requests) {
        this.requests = requests;
    }

    public void setProductions(List<Production> productions) {
        this.productions = productions;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }
}
