package org.example;

import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public abstract class User implements Comparable<User>, Observer {
    private Information user_info;
    private AccountType account_type;
    private String username;
    private int experience;
    protected List<String> notifications = new ArrayList<>();
    private List<String> favorite_production = new ArrayList<>();
    private List<String> contribution_productions = new ArrayList<>();
    private List<String> favorite_actors = new ArrayList<>();
    private List<String> contribution_actors = new ArrayList<>();
    private SortedSet<Object> favorites = new TreeSet<>();

    public User() {}
    public User(Information user_info, AccountType account_type, String username,
                int experience, List<String> notifications, SortedSet<Object> favorites) {
        this.user_info = user_info;
        this.account_type = account_type;
        this.username = username;
        this.experience = experience;
        this.notifications = notifications;
        this.favorites = favorites;
    }
    public static class Information {
        private Credentials credentials;
        private String name;
        private String country;
        private int age;
        private String gender;
        private LocalDateTime birth_date;
        public Information(InformationBuilder builder) {
            this.credentials = builder.credentials;
            this.name = builder.name;
            this.country = builder.country;
            this.age = builder.age;
            this.gender = builder.gender;
            this.birth_date = builder.birth_date;
        }

        public static class InformationBuilder {
            private Credentials credentials;
            private String name;
            private String country;
            private int age;
            private String gender;
            private LocalDateTime birth_date;
            public InformationBuilder(Credentials credentials, String name, String country,
                                      int age, String gender, LocalDateTime birth_date) {
                this.credentials = credentials;
                this.name = name;
                this.country = country;
                this.age = age;
                this.gender = gender;
                this.birth_date = birth_date;
            }
            public Information build() { return new Information(this);}
        }

        public Credentials getCredentials() {
            return credentials;
        }

        public String getCountry() {
            return country;
        }

        public int getAge() {
            return age;
        }

        public String getName() {
            return name;
        }

        public LocalDateTime getBirth_date() {
            return birth_date;
        }

        public String getGender() {
            return gender;
        }

        @Override
        public String toString() {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            return "Information: " +
                    "credentials = " + credentials + "\n" +
                    "name = " + name + "\n" +
                    "country = " + country + "\n" +
                    "age = " + age + "\n" +
                    "gender = " + gender + "\n" +
                    "birthdate = " + birth_date.format(formatter);
        }
    }

    public List<String> getContribution_actors() {
        return contribution_actors;
    }

    public List<String> getContribution_productions() {
        return contribution_productions;
    }

    public List<String> getFavorite_actors() {
        return favorite_actors;
    }

    public List<String> getFavorite_production() {
        return favorite_production;
    }

    public Information getUser_info() {
        return user_info;
    }

    public String getUsername() {
        return username;
    }

    public int getExperience() {
        return experience;
    }

    public AccountType getAccount_type() {
        return account_type;
    }

    public List<String> getNotifications() {
        return notifications;
    }

    public SortedSet<Object> getFavorites() {
        return favorites;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setFavorites(SortedSet<Object> favorites) {
        this.favorites = favorites;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public void setNotifications(List<String> notifications) {
        this.notifications = notifications;
    }

    public void setAccount_type(AccountType account_type) {
        this.account_type = account_type;
    }

    public void setUser_info(Information user_info) {
        this.user_info = user_info;
    }

    public void setContribution_actors(List<String> contribution_actors) {
        this.contribution_actors = contribution_actors;
    }

    public void setContribution_productions(List<String> contribution_productions) {
        this.contribution_productions = contribution_productions;
    }

    public void setFavorite_actors(List<String> favorite_actors) {
        this.favorite_actors = favorite_actors;
    }

    public void setFavorite_production(List<String> favorite_production) {
        this.favorite_production = favorite_production;
    }

    public void add_movie_fav(Movie movie) {
        favorites.add(movie);
    }
    public void add_series_fav(Series series) {
        favorites.add(series);
    }
    public void add_actor_fav(Actor actor) {
        favorites.add(actor);
    }
    public void remove_movie_fav(Movie movie) {
        favorites.remove(movie);
    }
    public void remove_series_fav(Series series) {
        favorites.remove(series);
    }
    public void remove_actor_fav(Actor actor) {
        favorites.remove(actor);
    }
    public void update_experience(int points) {
        experience += points;
    }

    public void user_info(Information user_info) {
        this.user_info = user_info;
    }

    public void logout() {
        if(this.notifications != null) this.notifications.clear();
        this.favorites.clear();

        System.out.println("Utilizatorul " + username + " a fost delogat.");
    }
    public int compareTo(User otherUser) {
        return this.username.compareTo(otherUser.username);
    }

    @Override
    public String toString() {
        return "User{" +
                "user_info=" + user_info +
                ", account_type=" + account_type +
                ", username='" + username + '\'' +
                ", experience=" + experience +
                ", notifications=" + notifications +
                ", favorite_production=" + favorite_production +
                ", contribution_productions=" + contribution_productions +
                ", favorite_actors=" + favorite_actors +
                ", contribution_actors=" + contribution_actors +
                ", favorites=" + favorites +
                '}';
    }
}
