package org.example;

public class UserFactory {
    public User createUser(AccountType type) {
        switch(type) {
            case REGULAR -> {
                return new Regular();
            }
            case CONTRIBUTOR -> {
                return new Contributor();
            }
            case ADMIN -> {
                return new Admin();
            }
            default -> {
                return null;
            }
        }
    }
}
