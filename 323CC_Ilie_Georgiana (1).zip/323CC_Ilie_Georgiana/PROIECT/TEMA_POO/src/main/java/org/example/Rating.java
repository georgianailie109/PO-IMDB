package org.example;

public class Rating {
    private String username;
    private int grade;
    private String comments;
    public Rating(String username, int grade, String comments) {
        this.username = username;
        this.grade = grade;
        this.comments = comments;
    }
    public void set_username(String username) {
        this.username = username;
    }
    public void set_grade(int grade) {
        this.grade = grade;
    }
    public void set_comments(String comments) {
        this.comments = comments;
    }
    public int get_grade() {
        return this.grade;
    }
    public String get_comments() {
        return this.comments;
    }
    public String get_username() {
        return this.username;
    }
    public String toString() {
        return "Rating: " +
                "username = " + username + "\n" +
                "grade = " + grade + "\n" +
                "comments = " + comments;
    }
}
