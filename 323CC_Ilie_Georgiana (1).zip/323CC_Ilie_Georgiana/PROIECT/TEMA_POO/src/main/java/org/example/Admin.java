package org.example;

import java.util.List;
import java.util.SortedSet;

public class Admin extends Staff implements RequestsManager{
    public Admin() {}

    public Admin(Information user_info, AccountType account_type, String username, int experience,
                 List<String> notifications, SortedSet<Object> favorites, List<Request> assigned_requests,
                 SortedSet<Object> addedProductionsActors) {
        super(user_info, account_type, username, experience, notifications, favorites,
                assigned_requests, addedProductionsActors);
    }

    @Override
    public void update(String notification) {
        this.notifications.add(notification);
    }

    @Override
    public void create_request(Request request) {
        System.out.println("Request created.");
        IMDB.getImdb().getRequests().add(request);

        if(request.getTo_username().equals("ADMIN"))
            RequestsHolder.add_request(request);
    }

    @Override
    public void remove_request(Request request) {
        System.out.println("Request removed.");
        IMDB.getImdb().getRequests().add(request);

        if(request.getTo_username().equals("ADMIN"))
            RequestsHolder.remove_request(request);
    }
}
