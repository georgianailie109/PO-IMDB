package org.example;
import java.util.List;
public class Movie extends Production{
    private String duration;
    private int release_year;

    public Movie() {}
    public Movie(String title, List<String> directors, List<String> actors,
                 List<Genre> genres, List<Rating> user_ratings,
                 String plot_description, double average_rating,
                 String duration, int release_year) {
        super(title, directors, actors, genres, user_ratings, plot_description, average_rating);
        this.duration = duration;
        this.release_year = release_year;
    }

    public String getDuration() {
        return this.duration;
    }
    public void setDuration(String duration) {
        this.duration = duration;
    }
    public int getRelease_year() {
        return this.release_year;
    }
    public void setRelease_year(int release_year) {
        this.release_year = release_year;
    }
    public void displayInfo() {
        System.out.println("Title: " + title);
        System.out.println("Directors: " + directors);
        System.out.println("Actors: " + actors);
        System.out.println("Genres: " + genres);
        System.out.println("Average Rating: " + average_rating);
        System.out.println("Plot Description: " + plot_description);
        System.out.println("Duration: " + duration + " minutes");
        System.out.println("Release Year: " + release_year);
    }
    public String toString() {
        return "Movie Details:\n" + super.toString() + "\n" +
                "Duration: " + duration + " minutes\n" +
                "Release Year: " + release_year;
    }
}
