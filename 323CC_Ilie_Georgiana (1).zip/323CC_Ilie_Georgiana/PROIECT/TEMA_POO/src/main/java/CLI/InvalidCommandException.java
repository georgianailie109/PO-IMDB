package CLI;

public class InvalidCommandException extends Exception {
    public InvalidCommandException() {
        super("Invalid command.");
    }
}
