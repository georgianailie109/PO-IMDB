package org.example;
import java.util.List;
import java.util.Objects;
import java.util.SortedSet;
public class Contributor extends Staff implements RequestsManager, ExperienceStrategy {
    public Contributor() {}

    public Contributor(Information user_info, String username,
                       int experience, List<String> notifications,
                       SortedSet<Object> favorites, List<Request> assigned_requests,
                       SortedSet<Object> addedProductionsActors) {
        super(user_info, AccountType.CONTRIBUTOR, username, experience, notifications, favorites,
                assigned_requests, addedProductionsActors);
    }
    public void create_request(Request request) {
        System.out.println("Request removed.");
        IMDB.getImdb().getRequests().add(request);

        if(request.getTo_username().equals("ADMIN"))
            RequestsHolder.add_request(request);
    }
    public void remove_request(Request request) {
        if(request.getRequest_type() == RequestTypes.OTHERS ||
                request.getRequest_type() == RequestTypes.DELETE_ACCOUNT || !request.getTo_username().equals(getUsername())) {
            System.out.println("You can not delete this request because it is not for you.");
        }
        System.out.println("Request removed.");
        IMDB.getImdb().getRequests().remove(request);

        if(request.getTo_username().equals("ADMIN"))
            RequestsHolder.remove_request(request);
    }

    @Override
    public void update(String notification) {
        this.notifications.add(notification);
    }

    @Override
    public int calculateExperience() {
        return 3;
    }
}
