package CLI;

import org.example.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class RunCLI {
    private int option = 0;
    private boolean is_running = true;
    Scanner sn = new Scanner(System.in);
    private User user = null;
    public RunCLI() throws InformationIncompleteException, InvalidCommandException {
        while(is_running) {
            switch(option) {
                case 0 -> logIn();
                case 1 -> viewProduction();     // view production
                case 2 -> viewActor();          // view actor
                case 3 -> viewNotifications();  // view notifications
                case 4 -> search();             // search actor / production
                case 5 -> changeFavorites();    // add / remove favorites
                case 6 -> changeUser();         // add / remove user
                case 7 -> changeRating();       // add / remove rating
                case 8 -> changeContent();      // add / remove actors / productions
                case 9 -> updateMovie();        // update movie
                case 10 -> updateActor();       // update actor
                case 11 -> solveRequest();      // solve request
                case 12 -> {
                    logout();                   // logout
                    continue;
                }
                default -> is_running = false;
            }

            // check if user wants to exit
            if(!is_running) break;

            System.out.println("Press any key to continue...");
            sn.nextLine();

            System.out.println("Welcome to the IMDB!");
            System.out.println("Please choose an option:");
            System.out.println("1. View production details");
            System.out.println("2. View actor details");
            System.out.println("3. View notifications");
            System.out.println("4. Search for actor/movie/series");
            System.out.println("5. Add/Delete actor/movie/series to/from favorites");
            System.out.println("6. Add/Delete user");
            System.out.println("7. Add/Delete rating to/from a production");
            System.out.println("8. Add/Delete actor/movie/series from system");
            System.out.println("9. Update movie details");
            System.out.println("10. Update actor details");
            System.out.println("11. Solve a request");
            System.out.println("12. Log out");
            System.out.println("13. Exit");

            System.out.print("Option: ");

            try {
                option = Integer.parseInt(sn.nextLine());
            } catch (NumberFormatException e) {
                throw new InvalidCommandException();
            }
        }

        System.out.println("The IMDB was closed.");
    }

    public void logIn() throws InformationIncompleteException {
        boolean is_logged = false;

        while(!is_logged) {
            System.out.println("Insert credentials:");
            System.out.print("Email: ");
            String email = sn.nextLine();
            System.out.print("Password: ");
            String password = sn.nextLine();

            if(email.isEmpty() || password.isEmpty())
                    throw new InformationIncompleteException();

            for(User user : IMDB.getImdb().getUsers()) {
                if(user.getUser_info().getCredentials().getEmail().equals(email) &&
                user.getUser_info().getCredentials().getPassword().equals(password)) {
                    this.user = user;
                    is_logged = true;
                    break;
                }
            }
        }
    }

    public void viewProduction() {
        System.out.print("Name of the production: ");
        String name = sn.nextLine();

        for(Production p : IMDB.getImdb().getProductions())
            if(p.get_title().equals(name)) {
                System.out.println(p);
                return;
            }

        System.out.println("Production doesn't exist in the IMDB.");
    }

    public void viewActor() {
        System.out.print("Name of the actor: ");
        String name = sn.nextLine();

        for(Actor a : IMDB.getImdb().getActors())
            if(a.getActor_name().equals(name)) {
                System.out.println(a);
                return;
            }

        System.out.println("Actor doesn't exist in the IMDB.");
    }

    public void viewNotifications() {
        System.out.println("Your notifications: ");
        System.out.println(this.user.getNotifications());
    }

    public void search() throws InvalidCommandException {
        System.out.print("Type the beginning of what do you want to find: ");
        String name = sn.nextLine();
        if(name.equals(""))
            throw new InvalidCommandException();

        // vreau sa afisez toate care incep cu acel nume, chiar daca utilizatorul scrie cu litere mici
        for(Production p : IMDB.getImdb().getProductions())
            if(p.get_title().toLowerCase().startsWith(name.toLowerCase()))
                System.out.println(p);

        for(Actor a : IMDB.getImdb().getActors())
            if(a.getActor_name().toLowerCase().startsWith(name.toLowerCase()))
                System.out.println(a);
    }

    public void changeFavorites() throws InvalidCommandException {
        System.out.println("What do you want?");
        System.out.println("1. Add to favorites");
        System.out.println("2. Remove from favorites");
        System.out.print("Option: ");

        int option;
        try {
            option = Integer.parseInt(sn.nextLine());
            if(option < 1 || option > 2) throw new InvalidCommandException();
        } catch (NumberFormatException e) {
            throw new InvalidCommandException();
        }

        System.out.print("Name: ");
        String name = sn.nextLine();

        Production p = null;
        Actor a = null;

        for(Production prod : IMDB.getImdb().getProductions())
            if(prod.get_title().equalsIgnoreCase(name)) {
                p = prod;
                break;
            }

        for(Actor actor : IMDB.getImdb().getActors())
            if(actor.getActor_name().equalsIgnoreCase(name)) {
                a = actor;
                break;
            }

        if(p == null && a == null) {
            System.out.println("There is no actor nor production with this name in the IMDB");
            return;
        }

        if(a != null && option == 1 && !this.user.getFavorite_actors().contains(a.getActor_name())) {
            this.user.getFavorite_actors().add(a.getActor_name());
            System.out.println("Actor added to the favorites");
        } else if(a != null && option == 1) {
            System.out.println("Actor is already in the favorites.");
            return;
        }

        if(a != null && option == 2 && !this.user.getFavorite_actors().contains(a.getActor_name())) {
            this.user.getFavorite_actors().remove(a.getActor_name());
            System.out.println("Actor removed from the favorites");
        } else if(a != null && option == 2) {
            System.out.println("Actor is not in the favorites.");
            return;
        }

        if(p != null && option == 1 && !this.user.getFavorite_production().contains(p.get_title())) {
            this.user.getFavorite_production().add(p.get_title());
            System.out.println("Production added to the favorites");
        } else if(p != null &&option == 1) {
            System.out.println("Production is already in the favorites.");
            return;
        }

        if(p != null && option == 2 && !this.user.getFavorite_production().contains(p.get_title())) {
            this.user.getFavorite_production().remove(p.get_title());
            System.out.println("Production removed from the favorites");
        } else if(p != null &&option == 2) {
            System.out.println("Production is not in the favorites.");
        }
    }

    public void changeUser() throws InvalidCommandException {
        if(this.user.getAccount_type() != AccountType.ADMIN) {
            System.out.println("You can not add/remove an user unless you are an admin.");
            return;
        }

        System.out.println("What do you want?");
        System.out.println("1. Add user");
        System.out.println("2. Remove user");
        System.out.print("Option: ");

        int option;
        try {
            option = Integer.parseInt(sn.nextLine());
            if(option < 1 || option > 2) throw new InvalidCommandException();
        } catch (NumberFormatException e) {
            throw new InvalidCommandException();
        }

        System.out.print("Name of the user: ");
        String name = sn.nextLine();

        if(name.equals("")) throw new InvalidCommandException();

        User user = null;
        for(User u : IMDB.getImdb().getUsers())
            if(u.getUsername().toLowerCase().equals(name.toLowerCase())) {
                user = u;
                break;
            }

        if(option == 2 && user == null) {
            System.out.println("User can not be removed if it doesn't exist in the IMDB.");
            return;
        }

        if(option == 1 && user != null) {
            System.out.println("User can not be added if it exists already in the IMDB.");
            return;
        }

        if(option == 2) {
            IMDB.getImdb().getUsers().remove(user);
            System.out.println("User removed from the IMDB.");
            return;
        }

        System.out.print("Email: ");
        String email = sn.nextLine();

        System.out.print("Password: ");
        String password = sn.nextLine();

        System.out.print("Country: ");
        String country = sn.nextLine();

        System.out.print("Gender: ");
        String gender = sn.nextLine();

        System.out.print("Age: ");
        int age;

        try {
            age = Integer.parseInt(sn.nextLine());
            if(age < 0 || age > 120) throw new InvalidCommandException();
        } catch (NumberFormatException e) {
            throw new InvalidCommandException();
        }

        System.out.print("BirthDate (yyyy-MM-dd): ");
        String date = sn.nextLine() + " 00:00:00";

        LocalDateTime birth_date;

        try {
            birth_date = LocalDateTime.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        } catch (Exception e) {
            throw new InvalidCommandException();
        }

        User.Information info = new User.Information.InformationBuilder(new Credentials(email, password),
                                            name, country, age, gender, birth_date).build();

        System.out.print("Accout Type: ");
        String type = sn.nextLine();

        AccountType user_type;

        switch(type.toLowerCase()) {
            case "admin" -> user_type = AccountType.ADMIN;
            case "regular" -> user_type = AccountType.REGULAR;
            case "contributor" -> user_type = AccountType.CONTRIBUTOR;
            default -> throw new InvalidCommandException();
        }

        switch(user_type) {
            case ADMIN -> user = new Admin();
            case CONTRIBUTOR -> user = new Contributor();
            case REGULAR -> user = new Regular();
        }

        user.setUser_info(info);
        user.setExperience(0);
        user.setUsername(name);
        user.setAccount_type(user_type);

        System.out.println("Account created. User added to the IMDB.");
    }

    public void changeRating() throws InvalidCommandException {
        if(this.user.getAccount_type() != AccountType.REGULAR) {
            System.out.println("You can not add/remove a rating unless you are a regular.");
            return;
        }

        System.out.println("What do you want?");
        System.out.println("1. Add rating");
        System.out.println("2. Remove rating");
        System.out.print("Option: ");

        int option;
        try {
            option = Integer.parseInt(sn.nextLine());
            if(option < 1 || option > 2) throw new InvalidCommandException();
        } catch (NumberFormatException | InvalidCommandException e) {
            throw new InvalidCommandException();
        }

        System.out.print("Name of production: ");
        String name = sn.nextLine();

        Production p = null;

        for(Production prod : IMDB.getImdb().getProductions())
            if(prod.get_title().equalsIgnoreCase(name)) {
                p = prod;
                break;
            }

        if(p == null) {
            System.out.println("Production doesn't exist in the IMDB.");
            return;
        }

        Rating r = null;

        for(Rating rat : p.get_ratings())
            if(rat.get_username().equals(user.getUsername())) {
                r = rat;
                break;
            }

        if(option == 2 && r == null) {
            System.out.println("You can not remove a rating that you didn't add.");
            return;
        }

        if(option == 1 && r != null) {
            System.out.println("You can not add a rating if you have already rated the production.");
            return;
        }

        if(option == 2) {
            p.get_ratings().remove(r);
            System.out.println("Rating removed.");
            return;
        }

        System.out.print("Your comment: ");
        String comment = sn.nextLine();

        System.out.print("Rating (1 to 10): ");
        int grade;

        try {
            grade = Integer.parseInt(sn.nextLine());
            if(grade < 1 || grade > 10) throw new InvalidCommandException();
        } catch (NumberFormatException e) {
            throw new InvalidCommandException();
        }

        r = new Rating(this.user.getUsername(), grade, comment);

        p.get_ratings().add(r);
        System.out.println("Rating added.");
    }
    public void changeContent() throws InvalidCommandException {
        if(user.getAccount_type() == AccountType.REGULAR) {
            System.out.println("You can not add / remove actors / productions as regular.");
            return;
        }

        System.out.println("What do you want to do?");
        System.out.println("1. Add content");
        System.out.println("2. Remove content");
        System.out.print("Option: ");
        int option;

        try {
            option = Integer.parseInt(sn.nextLine());
            if(option < 1 || option > 2) throw new InvalidCommandException();
        } catch (NumberFormatException e) {
            throw new InvalidCommandException();
        }

        Production prod = null;

        // remove option
        if(option == 2) {
            System.out.print("Name: ");
            String name = sn.nextLine();

            for(Actor a : IMDB.getImdb().getActors())
                if(a.getActor_name().equals(name)) {
                    if(user.getContribution_actors().contains(name) || user.getAccount_type() == AccountType.ADMIN) {
                        IMDB.getImdb().getActors().remove(a);
                        System.out.println("Actor has been removed from the IMDB.");
                        user.getContribution_actors().remove(name);

                        // update the user experience
                        user.setExperience(user.getExperience() - 3);
                    } else System.out.println("Actor can not be removed if it is in your list.");
                    return;
                }

            for(Production p : IMDB.getImdb().getProductions())
                if(p.get_title().equals(name)) {
                    if(user.getContribution_productions().contains(name) || user.getAccount_type() == AccountType.ADMIN) {
                        IMDB.getImdb().getProductions().remove(p);
                        System.out.println("Production has been removed from the IMDB.");
                        user.getContribution_productions().remove(name);

                        // update the user experience
                        user.setExperience(user.getExperience() - 3);
                    } else System.out.println("Production can not be removed if it is in your list.");
                    return;
                }
            System.out.println("No actor or production found in the IMDB.");
        }

        System.out.print("Type: ");
        String type = sn.nextLine();

        switch(type.toLowerCase()) {
            case "actor" -> {
                System.out.print("Actor name: ");
                String name = sn.nextLine();

                for(Actor actor : IMDB.getImdb().getActors())
                    if(actor.getActor_name().equals(name)) {
                        System.out.println("Actor already exists in the database.");
                        return;
                    }

                System.out.print("Actor biography: ");
                String biography = sn.nextLine();

                System.out.print("Number of performances: ");
                int num;

                try {
                    num = Integer.parseInt(sn.nextLine());
                    if(num < 1 || num > 10) throw new InvalidCommandException();
                } catch (NumberFormatException e) {
                    throw new InvalidCommandException();
                }

                List<Map<String, String>> performances = new ArrayList<>();
                for(int i = 0; i < num; i++) {
                    System.out.print("Title: ");
                    String title = sn.nextLine();

                    System.out.print("Type: ");
                    String production_type = sn.nextLine();

                    Map<String, String> production = new HashMap<>();
                    production.put(title, production_type);
                    performances.add(production);
                }
                IMDB.getImdb().getActors().add(new Actor(name, biography, performances));
                user.getContribution_actors().add(name);
                user.setExperience(user.getExperience() + 3);
                System.out.println("Actor has been added to the IMDB.");
                return;
            }
            case "movie" -> { // create movie
                System.out.print("Release year: ");
                int year;

                try {
                    year = Integer.parseInt(sn.nextLine());
                    if(year < 1920 || year > 2024) throw new InvalidCommandException();
                } catch (NumberFormatException e) {
                    throw new InvalidCommandException();
                }

                System.out.print("Duration: ");
                String duration = sn.nextLine();

                prod = new Movie();

                ((Movie) prod).setDuration(duration);
                ((Movie) prod).setRelease_year(year);
                prod.setType("Movie");
            }
            case "series" -> { // create series
                System.out.print("Release year: ");
                int year;

                try {
                    year = Integer.parseInt(sn.nextLine());
                    if(year < 1920 || year > 2024) throw new InvalidCommandException();
                } catch (NumberFormatException e) {
                    throw new InvalidCommandException();
                }

                System.out.print("Number of seasons: ");
                int num_seasons;

                try {
                    num_seasons = Integer.parseInt(sn.nextLine());
                    if(num_seasons < 1 || num_seasons > 30) throw new InvalidCommandException();
                } catch (NumberFormatException e) {
                    throw new InvalidCommandException();
                }

                Map<String, List<Episode>> seasons = new TreeMap<>();

                for(int i = 1; i <= num_seasons; i++) {
                    System.out.print("Number of episodes: ");
                    int num_episodes;

                    try {
                        num_episodes = Integer.parseInt(sn.nextLine());
                        if(num_episodes < 1 || num_episodes > 1200) throw new InvalidCommandException();
                    } catch (NumberFormatException e) {
                        throw new InvalidCommandException();
                    }

                    List<Episode> episodes = new ArrayList<>();

                    for(int j = 0; j < num_episodes; j++) {
                        String name = sn.nextLine();
                        System.out.print("Episode name: ");

                        System.out.print("Duration: ");
                        String duration = sn.nextLine();

                        episodes.add(new Episode(name, duration));
                    }

                    seasons.put("Season " + i, episodes);
                }

                prod = new Series();
                ((Series) prod).setRelease_year(year);
                ((Series) prod).set_nr_seasons(num_seasons);
                ((Series) prod).set_seasons(seasons);
                prod.setType("Series");
            }
            default -> throw new InvalidCommandException();
        }

        System.out.print("Name: ");
        String name = sn.nextLine();

        System.out.print("Number of directors: ");
        int num_directors;

        try {
            num_directors = Integer.parseInt(sn.nextLine());
            if(num_directors < 1 || num_directors > 10) throw new InvalidCommandException();
        } catch (NumberFormatException e) {
            throw new InvalidCommandException();
        }

        List<String> directors = new ArrayList<>();

        for(int i = 1; i <= num_directors; i++) {
            System.out.print("Director " + i + ": ");
            directors.add(sn.nextLine());
        }

        System.out.print("Number of actors: ");
        int num_actors;

        try {
            num_actors = Integer.parseInt(sn.nextLine());
            if(num_actors < 1 || num_actors > 10) throw new InvalidCommandException();
        } catch (NumberFormatException e) {
            throw new InvalidCommandException();
        }

        List<String> actors = new ArrayList<>();

        for(int i = 1; i <= num_actors; i++) {
            System.out.print("Actor " + i + ": ");
            actors.add(sn.nextLine());
        }

        System.out.print("Plot: ");
        String plot = sn.nextLine();

        System.out.print("Number of genres: ");
        int num_genres;

        try {
            num_genres = Integer.parseInt(sn.nextLine());
            if(num_genres < 1 || num_genres > 10) throw new InvalidCommandException();
        } catch (NumberFormatException e) {
            throw new InvalidCommandException();
        }

        List<Genre> genres = new ArrayList<>();

        for(int i = 1; i <= num_genres; i++) {
            System.out.print("Genre " + i + ": ");
            String genre = sn.nextLine();
            switch(genre) {
                case "Action" -> genres.add(Genre.ACTION);
                case "Adventure" -> genres.add(Genre.ADVENTURE);
                case "Biography" -> genres.add(Genre.BIOGRAPHY);
                case "Comedy" -> genres.add(Genre.COMEDY);
                case "Cooking" -> genres.add(Genre.COOKING);
                case "Crime" -> genres.add(Genre.CRIME);
                case "Drama" -> genres.add(Genre.DRAMA);
                case "Fantasy" -> genres.add(Genre.FANTASY);
                case "Horror" -> genres.add(Genre.HORROR);
                case "Mystery" -> genres.add(Genre.MYSTERY);
                case "Romance" -> genres.add(Genre.ROMANCE);
                case "SF" -> genres.add(Genre.SF);
                case "Thriller" -> genres.add(Genre.THRILLER);
                case "War" -> genres.add(Genre.WAR);
                default -> {}
            }
        }
        prod.set_directors(directors);
        prod.set_actors(actors);
        prod.set_description(plot);
        prod.set_genres(genres);
        prod.set_title(name);
    }

    public void solveRequest() {
        if(user.getAccount_type() == AccountType.REGULAR) {
            System.out.println("You can not solve a request as a regular.");
            return;
        }

        System.out.print("Type the username which created the request: ");
        String username = sn.nextLine();

        User user = null;

        for(User u : IMDB.getImdb().getUsers())
            if(u.getUsername().equals(username)) {
                user = u;
                break;
            }

        if(user == null) {
            System.out.println("Request doesn't exist.");
            return;
        }


        for(Request r : IMDB.getImdb().getRequests())
            if(r.getFrom_username().equals(username)) {
                if(r.getTo_username().equals("ADMIN") && this.user.getAccount_type() == AccountType.ADMIN) {
                    RequestsHolder.get_requests().remove(r);
                    IMDB.getImdb().getRequests().remove(r);
                    System.out.println("Request was marked as done.");
                    user.update("Your request was solved.");
                    break;
                }
                if(r.getTo_username().equals(this.user.getUsername())) {
                    IMDB.getImdb().getRequests().remove(r);
                    System.out.println("Request was marked as done.");
                    user.update("Your request was solved.");
                    break;
                }
            }

        System.out.println("Your request can not be solved.");
    }

    public void updateMovie() {
        if(this.user.getAccount_type() == AccountType.REGULAR) {
            System.out.println("You can not update a movie as a regular.");
            return;
        }

        System.out.print("Name: ");
        String name = sn.nextLine();

        if(!this.user.getContribution_productions().contains(name) &&
                this.user.getAccount_type() != AccountType.ADMIN) {
            System.out.println("You can not update a movie you didn't added.");
            return;
        }

        Production prod = null;

        for(Production p : IMDB.getImdb().getProductions())
            if(p.getType().equals("Movie") && p.get_title().equals(name)) {
                prod = p;
                break;
            }

        if(prod == null) {
            System.out.println("Production doesn't exist in the IMDB.");
            return;
        }

        System.out.print("New duration: ");
        String duration = sn.nextLine();

        ((Movie) prod).setDuration(duration);
        System.out.println("Movie updated.");
    }

    public void updateActor() throws InvalidCommandException {
        if(this.user.getAccount_type() == AccountType.REGULAR) {
            System.out.println("You can not update an actor as a regular.");
            return;
        }

        System.out.print("Name: ");
        String name = sn.nextLine();

        if(!this.user.getContribution_actors().contains(name) &&
                this.user.getAccount_type() != AccountType.ADMIN) {
            System.out.println("You can not update an actor you didn't added.");
            return;
        }

        Actor actor = null;

        for(Actor a : IMDB.getImdb().getActors())
            if(a.getActor_name().equals(name)) {
                actor = a;
                break;
            }

        if(actor == null) {
            System.out.println("Actor doesn't exist in the IMDB.");
            return;
        }

        System.out.print("New biography: ");
        String biography = sn.nextLine();

        System.out.println("How many new roles?");
        System.out.print("Write: ");
        int num_roles;

        try {
            num_roles = Integer.parseInt(sn.nextLine());
            if(num_roles < 0 || num_roles > 10) throw new InvalidCommandException();
        } catch (NumberFormatException e) {
            throw new InvalidCommandException();
        }

        List<Map<String, String>> roles = actor.getRoles();

        for(int i = 1; i <= num_roles; i++) {
            System.out.print("Title " + i + ": ");
            String title = sn.nextLine();

            System.out.print("Type: ");
            String type = sn.nextLine();

            Map<String, String> production = new HashMap<>();

            production.put(title, type);
            roles.add(production);
        }
        actor.setRoles(roles);
        actor.setBiography(biography);
        System.out.println("Actor updated.");
    }

    public void logout() {
        this.user.logout();
        this.user = null;
        this.option = 0; // log in
    }
}
