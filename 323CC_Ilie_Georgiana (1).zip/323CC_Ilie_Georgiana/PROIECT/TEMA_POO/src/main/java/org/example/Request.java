package org.example;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class Request {
    private RequestTypes request_type;
    private LocalDateTime creation_date;
    private String name;
    private String description;
    private String from_username;
    private String to_username;

    public Request() {}
    public Request(RequestTypes request_type, String name, String description,
                   String from_username, String to_username) {
        this.request_type = request_type;
        this.creation_date = LocalDateTime.now();
        this.name = name;
        this.description = description;
        this.from_username = from_username;
        this.to_username = to_username;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public LocalDateTime getCreation_date() {
        return creation_date;
    }

    public RequestTypes getRequest_type() {
        return request_type;
    }

    public String getFrom_username() {
        return from_username;
    }

    public String getTo_username() {
        return to_username;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCreation_date(LocalDateTime creation_date) {
        this.creation_date = creation_date;
    }

    public void setFrom_username(String from_username) {
        this.from_username = from_username;
    }

    public void setRequest_type(RequestTypes request_type) {
        this.request_type = request_type;
    }

    public void setTo_username(String to_username) {
        this.to_username = to_username;
    }

    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return  "Request type = " + request_type + "\n" +
                "Creation date = " + creation_date.format(formatter) + "\n" +
                "Production or actor name = " + name + "\n" +
                "Description = " + description + "\n" +
                "Requesting username = " + from_username + "\n" +
                "Resolving username = " + to_username ;
    }
}
