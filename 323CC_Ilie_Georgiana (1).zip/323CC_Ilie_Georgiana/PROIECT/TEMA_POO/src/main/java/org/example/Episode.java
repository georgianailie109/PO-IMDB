package org.example;
public class Episode {
    public String episode_name;
    private String duration;
    public Episode(String episode_name, String duration) {
        this.episode_name = episode_name;
        this.duration = duration;
    }
    public String get_episode_name() {
        return this.episode_name;
    }
    public void set_episode_name(String episode_name) {
        this.episode_name = episode_name;
    }
    public String get_duration() {
        return this.duration;
    }
    public void set_duration(String duration) {
        this.duration = duration;
    }

    @Override
    public String toString() {
        return "Episode: " +
                "episode name = " + episode_name + "\n" +
                "duration = " + duration;
    }
}
