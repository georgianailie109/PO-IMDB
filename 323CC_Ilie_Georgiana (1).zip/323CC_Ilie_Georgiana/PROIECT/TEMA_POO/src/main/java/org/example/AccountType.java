package org.example;

public enum AccountType {
    REGULAR,
    CONTRIBUTOR,
    ADMIN
}
