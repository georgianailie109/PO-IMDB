package org.example;

public enum Genre {
    ACTION,
    ADVENTURE,
    COMEDY,
    DRAMA,
    HORROR,
    COOKING,
    SF,
    FANTASY,
    ROMANCE,
    MYSTERY,
    THRILLER,
    CRIME,
    BIOGRAPHY,
    WAR
}
