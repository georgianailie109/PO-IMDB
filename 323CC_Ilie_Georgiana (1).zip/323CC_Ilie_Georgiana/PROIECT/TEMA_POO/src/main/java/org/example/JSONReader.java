package org.example;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

public class JSONReader {
    private ObjectMapper map = new ObjectMapper();
    IMDB imdb = IMDB.getImdb();
    private final String accounts_path = "src/test/resources/testResources/accounts.json";
    private final String actors_path = "src/test/resources/testResources/actors.json";
    private final String production_path = "src/test/resources/testResources/production.json";
    private final String requests_path = "src/test/resources/testResources/requests.json";
    public JSONReader() {
    }
    public void read_accounts() {
        try {
            List<Map<String, Object>> accounts = map.readValue(new File(accounts_path), List.class);

            for (Map<String, Object> account : accounts) {
                Map<String, String> credentials = (Map<String, String>) ((Map<String, Object>) account.get("information")).get("credentials");
                Credentials credential = new Credentials(credentials.get("email"), credentials.get("password"));

                Map<String, Object> information = (Map<String, Object>) account.get("information");
                String date = (String) information.get("birthDate");
                LocalDateTime birthDate = LocalDate.parse(date).atStartOfDay();

                String name = (String) information.get("name");
                String country = (String) information.get("country");
                String gender = (String) information.get("gender");
                int age = (int) information.get("age");

                User.Information info = new User.Information(
                         new User.Information.InformationBuilder(credential, name, country, age, gender, birthDate));

                List<String> contribution_productions = (List<String>) account.get("productionsContribution");
                List<String> contribution_actors = (List<String>) account.get("actorsContribution");

                List<String> notifications = (List<String>) account.get("notifications");

                List<String> favorite_actors = (List<String>) account.get("favoriteActors");
                List<String> favorite_productions = (List<String>) account.get("favoriteProductions");

                User user;
                String type = (String) account.get("userType");
                String experience = (String) account.get("experience");
                AccountType user_type;

                switch(type) {
                    case "Regular" -> user_type = AccountType.REGULAR;
                    case "Contributor" -> user_type = AccountType.CONTRIBUTOR;
                    case "Admin" -> user_type = AccountType.ADMIN;
                    default -> {
                        continue;
                    }
                }

                user = new UserFactory().createUser(user_type);
                user.setUser_info(info);
                user.setAccount_type(user_type);
                user.setUsername((String) account.get("username"));
                if(experience != null) user.setExperience(Integer.parseInt(experience));
                else user.setExperience(0);
                user.setNotifications(notifications);
                if(user.getNotifications() == null) user.setNotifications(new ArrayList<>());
                user.setFavorites(new TreeSet<>());
                user.setFavorite_actors(favorite_actors);
                user.setFavorite_production(favorite_productions);
                user.setContribution_actors(contribution_actors);
                user.setContribution_productions(contribution_productions);

                imdb.getUsers().add(user);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void read_actors() {
        try {
            List<Map<String, Object>> actors = map.readValue(new File(actors_path), List.class);

            for (Map<String, Object> actor : actors)
                // Add actors to the IMDB database
                imdb.getActors().add(new Actor((String) actor.get("name"), (String) actor.get("biography"),
                                                (List<Map<String, String>>) actor.get("performances")));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void read_productions() {
        try {
            List<Map<String, Object>> productions = map.readValue(new File(production_path), List.class);

            for (Map<String, Object> production : productions) {
                Production p;
                // Check production type and create corresponding object
                if(production.get("type").equals("Movie")) {
                    p = new Movie();
                    p.setType("Movie");
                    ((Movie) p).setDuration((String) production.get("duration"));

                    if(production.get("releaseYear") != null) ((Movie) p).setRelease_year((int) production.get("releaseYear"));
                } else {
                    p = new Series();
                    p.setType("Series");
                    ((Series) p).setRelease_year((int) production.get("releaseYear"));
                }

                p.set_title((String) production.get("title"));
                p.set_description((String) production.get("plot"));

                p.set_directors((List<String>) production.get("directors"));
                p.set_actors((List<String>) production.get("actors"));

                List<String> g = (List<String>) production.get("genres");
                List<Genre> genres = new ArrayList<>();

                for(String genre : g) {
                    switch(genre) {
                        case "Action" -> genres.add(Genre.ACTION);
                        case "Adventure" -> genres.add(Genre.ADVENTURE);
                        case "Biography" -> genres.add(Genre.BIOGRAPHY);
                        case "Comedy" -> genres.add(Genre.COMEDY);
                        case "Cooking" -> genres.add(Genre.COOKING);
                        case "Crime" -> genres.add(Genre.CRIME);
                        case "Drama" -> genres.add(Genre.DRAMA);
                        case "Fantasy" -> genres.add(Genre.FANTASY);
                        case "Horror" -> genres.add(Genre.HORROR);
                        case "Mystery" -> genres.add(Genre.MYSTERY);
                        case "Romance" -> genres.add(Genre.ROMANCE);
                        case "SF" -> genres.add(Genre.SF);
                        case "Thriller" -> genres.add(Genre.THRILLER);
                        case "War" -> genres.add(Genre.WAR);
                        default -> {}
                    }
                }

                p.set_genres(genres);

                List<Map<String, Object>> rating_json = (List<Map<String, Object>>) production.get("ratings");

                if(rating_json != null && !rating_json.isEmpty())
                    for(Map<String, Object> rating : rating_json)
                        p.get_ratings().add(new Rating((String) rating.get("username"),
                                (int) rating.get("rating"), (String) rating.get("comment")));

                if (production.get("type").equals("Series")) {
                    ((Series) p).set_nr_seasons((int) production.get("numSeasons"));

                    Map<String, List<Map<String, Object>>> seasons_json = (Map<String, List<Map<String, Object>>>) production.get("seasons");

                    for (Map.Entry<String, List<Map<String, Object>>> seasonEntry : seasons_json.entrySet()) {
                        List<Episode> episodes = new ArrayList<>();

                        for (Map<String, Object> e : seasonEntry.getValue())
                            episodes.add(new Episode((String) e.get("episodeName"), (String) e.get("duration")));

                        ((Series) p).get_seasons().put(seasonEntry.getKey(), episodes);
                    }
                }

                imdb.getProductions().add(p);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void read_requests() {
        try {
            List<Map<String, Object>> requests = map.readValue(new File(requests_path), List.class);

            for (Map<String, Object> request : requests) {
                Request req = new Request();

                if(request.get("movieTitle") != null) req.setName((String) request.get("movieTitle"));
                if(request.get("actorName") != null) req.setName((String) request.get("actorName"));

                switch((String) request.get("type")) {
                    case "DELETE_ACCOUNT" -> req.setRequest_type(RequestTypes.DELETE_ACCOUNT.DELETE_ACCOUNT);
                    case "MOVIE_ISSUE" -> req.setRequest_type(RequestTypes.MOVIE_ISSUE);
                    case "ACTOR_ISSUE" -> req.setRequest_type(RequestTypes.ACTOR_ISSUE);
                    case "OTHERS" -> req.setRequest_type(RequestTypes.OTHERS);
                    default -> {continue;}
                }

                Date date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse((String) request.get("createdDate"));

                req.setCreation_date(LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault()));
                req.setFrom_username((String) request.get("username"));
                req.setTo_username((String) request.get("to"));
                req.setDescription((String) request.get("description"));

                imdb.getRequests().add(req);

                // Process requests
                for(Request r : imdb.getRequests()) {
                    if(r.getRequest_type() == RequestTypes.OTHERS || r.getRequest_type() == RequestTypes.DELETE_ACCOUNT)
                        new RequestsHolder().get_requests().add(r);
                    else {
                        for(Object user : imdb.getUsers()) {
                            if(((User) user).getUsername().equals(r.getTo_username())) {
                                if(((User) user).getAccount_type() == AccountType.ADMIN) ((Admin) user).getAssigned_requests().add(r);
                                else ((Contributor) user).getAssigned_requests().add(r);
                            }
                        }
                    }
                }
            }
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    }
}
