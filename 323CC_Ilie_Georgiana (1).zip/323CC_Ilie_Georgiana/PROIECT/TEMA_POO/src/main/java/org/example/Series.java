package org.example;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Series extends Production {
    private int release_year;
    private int nr_seasons;
    private Map<String, List<Episode>> seasons = new TreeMap<>();

    public Series() {}
    public Series(String title, List<String> directors, List<String> actors,
                  List<Genre> genres, List<Rating> user_ratings,
                  String plot_description, double average_rating,
                  int release_year, int nr_seasons, Map<String, List<Episode>> seasons) {
        super(title, directors, actors, genres, user_ratings, plot_description, average_rating);
        this.release_year = release_year;
        this.nr_seasons = nr_seasons;
        this.seasons = seasons;
    }
    public int getRelease_year() {
        return this.release_year;
    }
    public void setRelease_year(int release_year) {
        this.release_year = release_year;
    }
    public int get_nr_seasons() {
        return this.nr_seasons;
    }
    public void set_nr_seasons(int nr_seasons) {
        this.nr_seasons = nr_seasons;
    }
    public Map<String, List<Episode>> get_seasons() {
        return seasons;
    }
    public void set_seasons(Map<String, List<Episode>> seasons) {
        this.seasons = seasons;
    }
    public void displayInfo() {
        System.out.println("Title: " + title);
        if(release_year != 0) {
            System.out.println("Release Year: " + release_year);
        }
        if(nr_seasons != 0) {
            System.out.println("Number of Seasons: " + nr_seasons);
        }
        System.out.println("Genres: " + genres);
        System.out.println("Average Rating: " + average_rating);
        if (plot_description != null) {
            System.out.println("Plot Description: " + plot_description);
        }
        if(seasons != null && !seasons.isEmpty()) {
            for(Map.Entry<String, List<Episode>> entry : seasons.entrySet()) {
                System.out.println("Season " + entry.getKey() + ":");
                List<Episode> episodes = entry.getValue();
                if(episodes != null && !episodes.isEmpty()) {
                    for(Episode episode: episodes) {
                        System.out.println(" - " + episode.episode_name);
                    }
                }
            }
        }
    }
    public String toString() {
        return "Series Details:\n" + super.toString() + "\n" +
                ((release_year != 0) ? "Release Year: " + release_year + "\n" : "") +
                ((nr_seasons != 0) ? "Number of Seasons: " + nr_seasons + "\n" : "") +
                ((plot_description != null) ? "Plot Description: " + plot_description + "\n" : "");
    }
}
