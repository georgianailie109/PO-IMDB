package org.example;
import java.util.ArrayList;
import java.util.List;

public abstract class Production implements Comparable<Object> {
    public String title, type;
    public List<String> directors = new ArrayList<>();
    public List<String> actors = new ArrayList<>();
    public List<Genre> genres = new ArrayList<>();
    public List<Rating> user_ratings = new ArrayList<>();
    public String plot_description;
    public double average_rating = 0;

    public Production() {}

    public Production(String title, List<String> directors, List<String> actors,
                      List<Genre> genres, List<Rating> user_ratings,
                      String plot_description, double average_rating) {
        this.title = title;
        this.directors = directors;
        this.actors = actors;
        this.genres = genres;
        this.user_ratings = user_ratings;
        this.plot_description = plot_description;
        this.average_rating = average_rating;
    }

    public String getType() {
        return type;
    }

    public String get_title() {
        return this.title;
    }
    public void set_title(String title) {
        this.title = title;
    }
    public List<String> get_directors() {
        return this.directors;
    }
    public void set_directors(List<String> directors) {
        this.directors = directors;
    }
    public List<String> get_actors() {
        return this.actors;
    }
    public void set_actors(List<String> actors) {
        this.actors = actors;
    }
    public List<Genre> get_genres() {
        return this.genres;
    }
    public void set_genres(List<Genre> genres) {
        this.genres = genres;
    }
    public List<Rating> get_ratings() {
        return this.user_ratings;
    }
    public void set_ratings(List<Rating> user_ratings) {
        this.user_ratings = user_ratings;
    }
    public String get_description() {
        return this.plot_description;
    }
    public void set_description(String plot_description) {
        this.plot_description = plot_description;
    }
    public double get_average() {
        return this.average_rating;
    }
    public void set_average(double average_rating) {
        this.average_rating = average_rating;
    }

    public void setType(String type) {
        this.type = type;
    }

    public abstract void displayInfo();
    public void add_rating(Rating rating) {
        if (user_ratings == null) {
            user_ratings = new ArrayList<>();
        }
        user_ratings.add(rating);
        average_rating = calculate_average();
    }
    private double calculate_average() {
        if (user_ratings == null || user_ratings.isEmpty()) {
            return 0.0;
        }
        double s = 0.0;
        for(Rating r : user_ratings) {
            s = s + r.get_grade();
        }
        return s / user_ratings.size();
    }
    public int compareTo(Object o) {
        if (o instanceof Production) {
            Production p = (Production) o;
            return this.title.compareTo(p.title);
        }
        return 0;
    }
    public String toString() {
        return "Title: " + title + "\n" +
                "Directors: " + directors + "\n" +
                "Actors: " + actors + "\n" +
                "Genres: " + genres + "\n" +
                "Average Rating: " + average_rating + "\n" +
                "Plot Description: " + plot_description;
    }
}
