package CLI;

public class InformationIncompleteException extends Exception {
    public InformationIncompleteException() {
        super("Invalid information. Email or/and password missing.");
    }
}
