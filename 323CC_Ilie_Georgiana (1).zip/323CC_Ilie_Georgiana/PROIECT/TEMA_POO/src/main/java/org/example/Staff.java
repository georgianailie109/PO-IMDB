package org.example;
import java.util.*;

public abstract class Staff extends User implements StaffInterface {
    public List<Request> assigned_requests = new ArrayList<>();
    private SortedSet<Object> addedProductionsActors = new TreeSet<>();

    public Staff() {}
    public Staff(Information user_info, AccountType account_type, String username,
                 int experience, List<String> notifications,
                 SortedSet<Object> favorites, List<Request> assigned_requests,
                 SortedSet<Object> addedProductionsActors) {
        super(user_info, account_type, username, experience, notifications, favorites);
        this.assigned_requests = assigned_requests;
        this.addedProductionsActors = addedProductionsActors;
    }
    public void addProductionSystem(Production p) {
        if(IMDB.getImdb().getProductions().contains(p)) {
            System.out.println("Production already exists in the IMDB.");
            return;
        }

        System.out.println("Production added in the IMDB.");
        addedProductionsActors.add(p);
        getContribution_actors().add(p.get_title());
    }
    public void addActorSystem(Actor a) {
        if(IMDB.getImdb().getActors().contains(a)) {
            System.out.println("Actor already exists in the IMDB.");
            return;
        }

        System.out.println("Actor added in the IMDB.");
        addedProductionsActors.add(a);
        getContribution_actors().add(a.getActor_name());
    }
    public void removeProductionSystem(String name) {
        if(getAccount_type() == AccountType.CONTRIBUTOR && !getContribution_productions().contains(name)) {
            System.out.println("You can not remove something you didn't add in the system.");
            return;
        }

        for(Production p : IMDB.getImdb().getProductions())
            if(p.get_title().equals(name)) {
                IMDB.getImdb().getProductions().remove(p);
                System.out.println("Production removed.");
                return;
            }

        System.out.println("Production doesn't exist in the IMDB.");
    }
    public void removeActorSystem(String name) {
        if(getAccount_type() == AccountType.CONTRIBUTOR && !getContribution_actors().contains(name)) {
            System.out.println("You can not remove something you didn't add in the system.");
            return;
        }

        for(Actor a : IMDB.getImdb().getActors())
            if(a.getActor_name().equals(name)) {
                IMDB.getImdb().getActors().remove(a);
                System.out.println("Actor removed.");
                return;
            }

        System.out.println("Actor doesn't exist in the IMDB.");
    }
    public void updateProduction(Production p) {
        if(getAccount_type() == AccountType.CONTRIBUTOR && !getContribution_actors().contains(p.get_title())) {
            System.out.println("You can not remove something you didn't add in the system.");
            return;
        }

        for(Production prod : IMDB.getImdb().getProductions())
            if(prod.get_title().equals(p.get_title())) {
                IMDB.getImdb().getProductions().remove(prod);
                IMDB.getImdb().getProductions().add(p);
                System.out.println("Production updated.");
                return;
            }

        System.out.println("Production doesn't exist in the IMDB.");
    }
    public void updateActor(Actor a) {
        if(getAccount_type() == AccountType.CONTRIBUTOR && !getContribution_actors().contains(a.getActor_name())) {
            System.out.println("You can not remove something you didn't add in the system.");
            return;
        }

        for(Actor actor : IMDB.getImdb().getActors())
            if(actor.getActor_name().equals(a.getActor_name())) {
                IMDB.getImdb().getActors().remove(actor);
                IMDB.getImdb().getActors().add(a);
                System.out.println("Actor updated.");
                return;
            }

        System.out.println("Actor doesn't exist in the IMDB.");
    }
    public List<Request> getAssigned_requests() {
        return assigned_requests;
    }

    public void setAssigned_requests(List<Request> assigned_requests) {
        this.assigned_requests = assigned_requests;
    }
}
