package org.example;
import CLI.InvalidCommandException;

import java.util.List;
import java.util.Objects;
import java.util.SortedSet;

public class Regular extends User implements RequestsManager, ExperienceStrategy {
    private List<Request> requests;

    public Regular() {}
    public Regular(Information user_info, AccountType account_type, String username,
                   int experience, List<String> notifications,
                   SortedSet<Object> favorites, List<Request> requests) {
        super(user_info, account_type, username, experience, notifications, favorites);
        this.requests = requests;
    }
    @Override
    public void create_request(Request request) {
        System.out.println("Request created.");
        IMDB.getImdb().getRequests().add(request);

        if(request.getTo_username().equals("ADMIN"))
            RequestsHolder.add_request(request);
    }
    @Override
    public void remove_request(Request request) {
        if(request.getRequest_type() == RequestTypes.OTHERS ||
                request.getRequest_type() == RequestTypes.DELETE_ACCOUNT || !request.getTo_username().equals(getUsername())) {
            System.out.println("You can not delete this request because it is not for you.");
        }
        System.out.println("Request removed.");
        IMDB.getImdb().getRequests().remove(request);

        if(request.getTo_username().equals("ADMIN"))
            RequestsHolder.remove_request(request);
    }
    public void addReview(Production p, String comment, int grade) {
        if(grade < 1 || grade > 10) return;

        for(Rating r : p.get_ratings())
            if(r.get_username().equals(getUsername())) {
                System.out.println("You already reviewed this production.");
                return;
            }

        p.get_ratings().add(new Rating(getUsername(), grade, comment));
        System.out.println("Review added to the product.");
        setExperience(getExperience() + calculateExperience());
    }

    public void removeReview(Production p) {
        for(Rating r : p.get_ratings())
            if(r.get_username().equals(getUsername())) {
                p.get_ratings().remove(r);
                setExperience(getExperience() - calculateExperience());
                System.out.println("Review removed from the product");
                return;
            }

        System.out.println("You didn't reviewd this product.");
    }

    @Override
    public int calculateExperience() {
        return 3;
    }

    @Override
    public void update(String notification) {
        notifications.add(notification);
    }
}
