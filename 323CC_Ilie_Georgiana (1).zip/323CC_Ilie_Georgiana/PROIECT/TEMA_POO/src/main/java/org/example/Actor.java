package org.example;
import java.util.List;
import java.util.Map;
public class Actor {
    private String actor_name;
    private List<Map<String, String>> roles;
    private String biography;

    public Actor() {}
    public Actor(String actor_name, String biography, List<Map<String, String>> roles) {
        this.actor_name = actor_name;
        this.biography = biography;
        this.roles = roles;
    }

    public String getBiography() {
        return biography;
    }

    public List<Map<String, String>> getRoles() {
        return roles;
    }

    public String getActor_name() {
        return actor_name;
    }

    public void setBiography(String biography) {
        this.biography = biography;
    }

    public void setActor_name(String actor_name) {
        this.actor_name = actor_name;
    }

    public void setRoles(List<Map<String, String>> roles) {
        this.roles = roles;
    }

    @Override
    public String toString() {
        return "Actor: " + "actor_name = " + actor_name + "\n" +
                "roles = " + roles + "\n" +
                "biography = " + biography;
    }
}
